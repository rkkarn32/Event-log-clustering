/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sampleproject;

/**
 *
 * @author Ramesh
 */
public class Variable {
    public static String FileName = "merged.log";
    //public static String FileName = "merged.log";
}
