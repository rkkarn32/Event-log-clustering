/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sampleproject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.StringTokenizer;
import javax.swing.JOptionPane;

/**
 *
 * @author Ramesh
 */ 
public class CreatModel {
    
    SqlConnection sql =new SqlConnection();
    VerifyWords Verify = new VerifyWords();
    ResultSet rs;
    
    public void ValueCalculation(){
        try{
            FileReader readfile = new FileReader(new Variable().FileName);
            BufferedReader bfread = new BufferedReader(readfile);
            String sentences;
            String Delim =" ,@";
            StringTokenizer Token;
//            ArrayList <Integer> Value = new ArrayList<Integer>();
            
            while ((sentences = bfread.readLine()) != null) {
                
                sentences = Verify.ReplaceIP(sentences);
                sentences = Verify.ReplaceMAC(sentences);
                sentences = Verify.ReplaceDate(sentences);
                sentences = Verify.ReplaceTime(sentences);
                
                int sum=0;
                
                String CheckWord;
                Token = new StringTokenizer(sentences, Delim);
                while (Token.hasMoreElements()) {
                    CheckWord = Token.nextToken();
                    String query ="SELECT * FROM word WHERE word='"+CheckWord+"'";
                    rs = sql.ExecuteQuery(query);
                    rs.next();
//                    System.out.println(rs.getString("word")+" "+rs.getString("count")+" "+rs.getString("weightage"));
                    sum+= Integer.parseInt(rs.getString("count"))* Integer.parseInt(rs.getString("weightage"))* Str2Byte(CheckWord);
                }
                System.out.println(sentences +" -->> "+ sum);
                String UpdateQuery = "INSERT INTO model VALUES("+null+",'"+ sentences+"','"+sum+"')";
                sql.UpdateQuery(UpdateQuery);
            }
        }catch(FileNotFoundException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "File not found", 2);
        }catch(IOException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "IOException ", 2);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "SQLException", 2);
        }
    }
    
    public void Model2File(){
        try{
            FileWriter fwrt = new FileWriter("w.txt");
            BufferedWriter bf =new BufferedWriter(fwrt) ;
            String Query = "SELECT * FROM model ORDER BY value DESC";
            rs = sql.ExecuteQuery(Query);
            int a=0;
            while(rs.next()){
                bf.write(rs.getString("value")+"   "+rs.getString("sentence")+"\n");
                bf.flush();
                a++;
            }
            System.out.println(a);
        }catch(IOException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "IOException Error", 2);
        }catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex.getMessage(), "SQLException Error", 2);
        }
        
        
        // Write the data of Model Table by "Desc order". to the file to analyse it visually ...
        
    }    
    
    public static void main(String[] args) {
        new CreatModel().ValueCalculation();
        new CreatModel().Model2File();
    }

    private int Str2Byte(String Word) {
//        ArrayList<String> sgrings = new ArrayList<String>(Arrays.asList("rameshe","rameshea","ganesh","lekhnath","sanjay"));
//            System.out.println(sgrings.get(i));
            int sum =0;
            for(int j =0; j< Word.length();j++){
                char c= Word.charAt(j);
                if(Character.isLetter(c)){
                    if(Character.isLowerCase(c)){
                        int value =c-'a'+1;
                        value*=2;
//                        sum+=value;
                        sum+= ((Word.length()-j)/2 +1)*value;
//                        sum+= (j+1) *value;
                        //System.out.println(c +"= "+ value+ " sum= "+sum);
                    }
                    else if(Character.isUpperCase(c)){
                        int value =c-'A'+1;
                        value*=2;
                        sum+= ((Word.length()-j)/2 +1)*value;
//                        sum+= (j+1)*value;
//                        sum+=value;
                        //System.out.println(c +"= "+ value+ " sum= "+sum);
                    }
                }
//                if((j== Word.length()/2-1) ){
//                    sum*=2;
//                }
            }
//            System.out.println(sgrings.get(i)+" = "+ sum);
            return sum;                
        }
}
