/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sampleproject;
import java.io.IOException;

/**
 *
 * @author Ramesh
 */
public class SampleProject {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        FileOperation Work = new FileOperation();
        Work.ReadNUpdateFile();
        
        CreatModel CrModel = new CreatModel();
        CrModel.ValueCalculation();             //Creates the model in Model Table..
        CrModel.Model2File();                   //Save the value to the file...
        
        
        
//        CreatModel UpdateModel = new CreatModel();
//        CreatModel.main(args);
        
//            ok.CreateFile("newFile.log");
    }
}
